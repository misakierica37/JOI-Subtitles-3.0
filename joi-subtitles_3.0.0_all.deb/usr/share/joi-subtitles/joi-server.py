#!/usr/bin/env python3
"""
JOI Subtitles 3.0 — Local Backend Server for Linux Mint (.deb Package)
100% keyless speech recognition (Firefox WebAudio WAV + Linux Mint ALSA arecord fallback)
and Google Neural Machine Translation (en -> ro).
"""
import audioop
import http.server
import io
import json
import math
import os
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import wave
from pathlib import Path

DIST_DIR = Path("/usr/share/joi-subtitles/dist")
if not DIST_DIR.exists():
    DIST_DIR = Path(__file__).resolve().parent / "dist"

IS_LISTENING = False
LAST_BROWSER_AUDIO_TS = 0.0
LAST_RMS_LEVEL = 0
PENDING_TRANSCRIPTS = []
STATE_LOCK = threading.Lock()

TRANSLATION_CACHE = {
    "Welcome everyone to today's presentation on system architecture and performance.":
        "Bun venit tuturor la prezentarea de astăzi despre arhitectura sistemului și performanță.",
    "Our main goal is to deliver reliable real-time subtitles on lightweight Linux hardware.":
        "Obiectivul nostru principal este să oferim subtitrări fiabile în timp real pe hardware Linux ușor.",
    "The floating caption bar stays on top of your slides and browser windows throughout the event.":
        "Bara plutitoare de subtitrări rămâne deasupra diapozitivelor și ferestrelor browserului pe tot parcursul evenimentului.",
    "Thank you for your attention, and let us open the floor for questions and discussion.":
        "Vă mulțumesc pentru atenție și haideți să deschidem sesiunea pentru întrebări și discuții.",
}


def translate_en_to_ro(text: str):
    clean = " ".join(text.strip().split())
    if not clean:
        return "", "empty", False
    if clean in TRANSLATION_CACHE:
        return TRANSLATION_CACHE[clean], "neural-cache", True

    try:
        q = urllib.parse.quote(clean)
        url = f"https://translate.googleapis.com/translate_a/t?client=dict-chrome-ex&sl=en&tl=ro&q={q}"
        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
            },
        )
        with urllib.request.urlopen(req, timeout=3.5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            translated = ""
            if isinstance(data, list) and len(data) > 0:
                if isinstance(data[0], str):
                    translated = " ".join(x for x in data if isinstance(x, str)).strip()
                elif isinstance(data[0], list):
                    parts = []
                    for item in data[0]:
                        if isinstance(item, list) and len(item) > 0 and isinstance(item[0], str):
                            parts.append(item[0])
                        elif isinstance(item, str):
                            parts.append(item)
                    translated = "".join(parts).strip()
            if translated:
                TRANSLATION_CACHE[clean] = translated
                return translated, "google-nmt", False
    except Exception:
        pass

    return clean, "local-fallback", False


def transcribe_wav_bytes(raw_body: bytes):
    try:
        with wave.open(io.BytesIO(raw_body), "rb") as wf:
            sample_rate = wf.getframerate() or 16000
            n_channels = wf.getnchannels() or 1
            sampwidth = wf.getsampwidth() or 2
            pcm_bytes = wf.readframes(wf.getnframes())
        if not pcm_bytes:
            return "", 0.0
        if n_channels > 1:
            pcm_bytes = audioop.tomono(pcm_bytes, sampwidth, 0.5, 0.5)
        if sampwidth != 2:
            pcm_bytes = audioop.lin2lin(pcm_bytes, sampwidth, 2)
        if sample_rate != 16000:
            pcm_bytes, _ = audioop.ratecv(pcm_bytes, 2, 1, sample_rate, 16000, None)
            sample_rate = 16000

        # Boost quiet laptop microphones automatically
        max_amp = audioop.max(pcm_bytes, 2)
        if 80 < max_amp < 14000:
            gain = min(5.5, 22000.0 / float(max_amp))
            pcm_bytes = audioop.mul(pcm_bytes, 2, gain)

        g_url = (
            "https://www.google.com/speech-api/v2/recognize"
            "?client=chromium&lang=en-US&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&pFilter=0"
        )
        g_req = urllib.request.Request(
            g_url,
            data=pcm_bytes,
            headers={"Content-Type": f"audio/l16; rate={sample_rate}"},
            method="POST",
        )
        with urllib.request.urlopen(g_req, timeout=7.0) as g_resp:
            g_text = g_resp.read().decode("utf-8")
            for line in g_text.split("\n"):
                line = line.strip()
                if not line:
                    continue
                parsed = json.loads(line)
                results = parsed.get("result", [])
                if results and results[0].get("alternative"):
                    alts = results[0]["alternative"]
                    best = max(alts, key=lambda a: a.get("confidence", 0.5))
                    transcript = best.get("transcript", "").strip()
                    if transcript:
                        return transcript, float(best.get("confidence", 0.94))
    except Exception:
        pass
    return "", 0.0


def alsa_mic_worker():
    """
    Background fallback worker for Linux Mint:
    If the user clicked 'Start Listening' in Firefox and browser WebAudio hasn't delivered
    audio chunks (e.g., if localhost mic permission prompt was dismissed), captures 2-second
    16kHz WAV chunks directly via Linux Mint's built-in 'arecord' utility.
    """
    global LAST_RMS_LEVEL
    arecord_bin = shutil.which("arecord")
    if not arecord_bin:
        return

    while True:
        time.sleep(0.25)
        with STATE_LOCK:
            active = IS_LISTENING
            browser_recent = (time.time() - LAST_BROWSER_AUDIO_TS) < 2.8
        if not active or browser_recent:
            continue

        try:
            proc = subprocess.run(
                [arecord_bin, "-q", "-f", "S16_LE", "-r", "16000", "-c", "1", "-d", "2", "-t", "wav", "-"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=4.0,
            )
            wav_data = proc.stdout
            if not wav_data or len(wav_data) <= 44:
                continue
            pcm = wav_data[44:]
            rms = audioop.rms(pcm, 2)
            scaled = min(100, int(math.sqrt(rms / 32768.0) * 220))
            with STATE_LOCK:
                LAST_RMS_LEVEL = scaled
            # Only transcribe when voice energy is present
            if rms > 120:
                transcript, conf = transcribe_wav_bytes(wav_data)
                if transcript:
                    with STATE_LOCK:
                        if IS_LISTENING:
                            PENDING_TRANSCRIPTS.append({"text": transcript, "confidence": conf})
        except Exception:
            time.sleep(0.5)


class ReusableThreadingHTTPServer(http.server.ThreadingHTTPServer):
    allow_reuse_address = True


class JoiHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DIST_DIR), **kwargs)

    def log_message(self, format, *args):
        pass

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def _send_json(self, status_code: int, payload: dict):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        clean_path = self.path.split("?", 1)[0]
        if clean_path == "/api/status":
            self._send_json(200, {
                "translationEngine": "Google Neural NMT (en -> ro) [.deb]",
                "cacheEntries": len(TRANSLATION_CACHE),
                "targetHardwareProfile": "Intel Celeron N2940 (4GB RAM) / Linux Mint",
            })
            return

        if clean_path == "/api/listen/poll":
            with STATE_LOCK:
                items = list(PENDING_TRANSCRIPTS)
                PENDING_TRANSCRIPTS.clear()
                rms = LAST_RMS_LEVEL
            self._send_json(200, {"transcripts": items, "rmsLevel": rms})
            return

        # CRITICAL FOR FIREFOX: Remove conditional caching headers so SimpleHTTPRequestHandler
        # NEVER returns HTTP 304 Not Modified and always serves the latest dist files!
        if "If-Modified-Since" in self.headers:
            del self.headers["If-Modified-Since"]
        if "If-None-Match" in self.headers:
            del self.headers["If-None-Match"]
        self.path = clean_path
        return super().do_GET()

    def do_POST(self):
        global IS_LISTENING, LAST_BROWSER_AUDIO_TS, LAST_RMS_LEVEL
        clean_path = self.path.split("?", 1)[0]
        content_len = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(content_len) if content_len > 0 else b""

        if clean_path == "/api/listen/start":
            with STATE_LOCK:
                IS_LISTENING = True
                PENDING_TRANSCRIPTS.clear()
            self._send_json(200, {"listening": True})
            return

        if clean_path == "/api/listen/stop":
            with STATE_LOCK:
                IS_LISTENING = False
                LAST_RMS_LEVEL = 0
                PENDING_TRANSCRIPTS.clear()
            self._send_json(200, {"listening": False})
            return

        if clean_path == "/api/translate":
            t0 = time.time()
            try:
                data = json.loads(raw_body.decode("utf-8"))
                text = str(data.get("text", "")).strip()
            except Exception:
                text = ""
            if not text:
                self._send_json(400, {"error": "Empty text provided"})
                return
            romanian, provider, cached = translate_en_to_ro(text)
            latency_ms = max(1, int((time.time() - t0) * 1000))
            self._send_json(200, {
                "english": text,
                "romanian": romanian,
                "cached": cached,
                "provider": provider,
                "latencyMs": latency_ms,
            })
            return

        if clean_path == "/api/deepgram/transcribe":
            with STATE_LOCK:
                LAST_BROWSER_AUDIO_TS = time.time()
            transcript, conf = transcribe_wav_bytes(raw_body)
            self._send_json(200, {
                "transcript": transcript,
                "confidence": conf,
                "source": "deepgram",
            })
            return

        self._send_json(404, {"error": "Not found"})


def main():
    t = threading.Thread(target=alsa_mic_worker, daemon=True)
    t.start()
    port = int(os.environ.get("JOI_PORT", "38475"))
    server = None
    for candidate in [port, 38476, 38470, 0]:
        try:
            server = ReusableThreadingHTTPServer(("127.0.0.1", candidate), JoiHandler)
            break
        except OSError:
            continue
    actual_port = server.server_address[1]
    port_file = os.environ.get("JOI_PORT_FILE", "")
    if port_file:
        Path(port_file).write_text(str(actual_port), encoding="utf-8")
    print(f"JOI_SUBTITLES_READY=http://localhost:{actual_port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
